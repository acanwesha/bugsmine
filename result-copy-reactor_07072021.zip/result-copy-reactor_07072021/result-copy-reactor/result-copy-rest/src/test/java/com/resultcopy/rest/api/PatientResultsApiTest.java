package com.resultcopy.rest.api;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.io.IOException;

import javax.ws.rs.NotFoundException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;

import org.junit.Test;
import org.junit.jupiter.api.Assertions;

import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.resultcopy.rest.api.factory.PatientResultsApiServiceFactory;

/**
 * @author AC089545
 * Test case for {@link PatientResultsApi}
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest(PatientResultsApiServiceFactory.class)
public class PatientResultsApiTest {
    @Mock
    SecurityContext securityContext;
    @Mock
    Response responseMock;
    @Mock
    PatientResultsApiService patientResultsApiServiceMock;

    /**
     * Test to check whether the response of patientId is returned successfully.
     * @throws NotFoundException if patientId not found.
     */
    @Test
    public void testPatientResultsPatientId() throws com.resultcopy.rest.api.NotFoundException, IOException {
    	PowerMockito.mockStatic(PatientResultsApiServiceFactory.class);
    	when(PatientResultsApiServiceFactory.getPatientResultsApi()).thenReturn(patientResultsApiServiceMock);
        when(patientResultsApiServiceMock.patientResultsPatientIdGet(any(String.class), any(SecurityContext.class))).thenReturn(responseMock);
        Response response = new PatientResultsApi().patientResultsPatientIdGet("1", securityContext);
        assertNotNull(response);

    }
}