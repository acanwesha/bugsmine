package com.resultcopy.service.impl;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import com.resultcopy.PatientDetailsResponse;
import com.resultcopy.PatientResponse;
import lombok.ToString;

/**
 * Test cases for PatientDAOImpl class.
 */
@ToString
@RunWith(MockitoJUnitRunner.class)
public class PatientDAOImplTest {
    @Mock
    private Connection connection;
    @Mock
    private PreparedStatement preparedStatement;
    @Mock
    private ResultSet resultSet;

    /**
     * Test case for the method to get the patient details.
     * @throws SQLException Throws exception when patient details not found.
     */
    @Test
    public void getPatientById() throws SQLException {
        PatientDetailsResponse patientDetails = new PatientDetailsResponse();
        patientDetails.setId(1);
        patientDetails.setFirstName("EMMA");
        patientDetails.setLastName("ESPINOSA");
        patientDetails.setMrn("MX13216584");
        patientDetails.setFin(" MX26548913");
        when(connection.prepareStatement(any(String.class))).thenReturn(preparedStatement);
        when(preparedStatement.executeQuery()).thenReturn(resultSet);
        when(resultSet.first()).thenReturn(true);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getInt(any(String.class))).thenReturn(patientDetails.getId());
        when(resultSet.getString("FIRST_NAME")).thenReturn(patientDetails.getFirstName());
        when(resultSet.getString("LAST_NAME")).thenReturn(patientDetails.getLastName());
        when(resultSet.getString("MRN")).thenReturn(patientDetails.getMrn());
        when(resultSet.getString("FIN")).thenReturn(patientDetails.getFin());
        PatientResponse result = new PatientDAOImpl(connection).getPatientById(1);
        Assertions.assertEquals(result.getPatientDetails().getId(), patientDetails.getId());
        Assertions.assertEquals(result.getPatientDetails().getFirstName(), patientDetails.getFirstName());
        Assertions.assertEquals(result.getPatientDetails().getLastName(), patientDetails.getLastName());
    }

    /**
     * Test to check the exception case.
     * @throws SQLException Throws exception when patient details not found.
     */
    @Test
    public void testException() throws SQLException {

        when(connection.prepareStatement(any(String.class))).thenThrow((new SQLException()));
        PatientResponse result = new PatientDAOImpl(connection).getPatientById(1);
        Assertions.assertNull(result);
    }

    /**
     * Test case for constructor.
     */
    @Test
    public void testConstructor() {
        PatientDAOImpl patientDAOImpl = new PatientDAOImpl();
        Assertions.assertNotNull(patientDAOImpl);
    }
}
