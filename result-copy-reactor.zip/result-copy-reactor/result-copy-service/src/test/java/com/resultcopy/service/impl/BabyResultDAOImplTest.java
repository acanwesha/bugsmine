package com.resultcopy.service.impl;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import com.resultcopy.BabyRequest;
import com.resultcopy.BabyResultResponse;
import com.resultcopy.CategoryRequest;
import com.resultcopy.ResultRequest;
import lombok.ToString;

/**
 * @author AC089545
 * Test cases for BabyResultDAOImpl.
 */
@ToString
@RunWith(MockitoJUnitRunner.class)
public class BabyResultDAOImplTest {
    @Mock
    private Connection connection;
    @Mock
    private PreparedStatement preparedStatement;
    @Mock
    private ResultSet resultSet;

    /**
     * Test case for baby result.
     * @throws SQLException The SQLException is thrown when data is not found.
     */
    @Test
    public void testGetBabyPatientByChildId() throws SQLException {
        BabyResultResponse resultResponse = new BabyResultResponse();
        resultResponse.setDateTime(null);
        when(connection.prepareStatement(any(String.class))).thenReturn(preparedStatement);
        when(preparedStatement.executeQuery()).thenReturn(resultSet);
        when(resultSet.first()).thenReturn(true);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getDate("DATE_TIME")).thenReturn((java.sql.Date)resultResponse.getDateTime());
        BabyResultResponse result = new BabyResultDAOImpl(connection).getBabyPatientByChildId(12);
        Assertions.assertNull(result.getDateTime());
    }

    /**
     * Test case to copy the result to baby.
     * @throws SQLException Exception is thrown when copy is unsuccessful.
     */
    @Test
    public void testCreateBabyResult() throws SQLException {
        List<ResultRequest> resultRequests = new ArrayList<>();
        ResultRequest resultRequest = new ResultRequest();
        resultRequest.setValue("TEST");
        resultRequest.setDisplayName("TEST_DISPLAY_NAME");
        resultRequests.add(resultRequest);
        List<CategoryRequest> category = new ArrayList<>();
        CategoryRequest categoryRequest = new CategoryRequest();
        categoryRequest.setDisplayName("CATEGORY");
        categoryRequest.setResult(resultRequests);
        category.add(categoryRequest);
        BabyRequest babyRequest = new BabyRequest();
        babyRequest.setChildId(11);
        babyRequest.setCategory(category);
        when(connection.prepareStatement(any(String.class))).thenReturn(preparedStatement);
        boolean result = new BabyResultDAOImpl(connection).createBabyResult(babyRequest);
        Assertions.assertTrue(result);
    }

    /**
     * Test to check the exception case for getting baby result.
     * @throws SQLException Exception is thrown when copy is unsuccessful.
     */
    @Test
    public void testExceptionGetBabyPatientByChildId() throws SQLException {
        when(connection.prepareStatement(any(String.class))).thenThrow((new SQLException()));
        BabyResultResponse result = new BabyResultDAOImpl(connection).getBabyPatientByChildId(12);
        Assertions.assertNull(result);
    }

    /**
     * Test to check the exception case for copying the baby result.
     * @throws SQLException Exception is thrown when copy is unsuccessful.
     */
    @Test
    public void testExceptionCreateBabyResult() throws SQLException {
        List<ResultRequest> resultRequests = new ArrayList<>();
        ResultRequest resultRequest = new ResultRequest();
        resultRequest.setValue("TEST");
        resultRequest.setDisplayName("TEST_DISPLAY_NAME");
        resultRequests.add(resultRequest);
        List<CategoryRequest> category = new ArrayList<>();
        CategoryRequest categoryRequest = new CategoryRequest();
        categoryRequest.setDisplayName("CATEGORY");
        categoryRequest.setResult(resultRequests);
        category.add(categoryRequest);
        BabyRequest babyRequest = new BabyRequest();
        babyRequest.setChildId(11);
        babyRequest.setCategory(category);
        when(connection.prepareStatement(any(String.class))).thenThrow((new SQLException()));
        boolean result = new BabyResultDAOImpl(connection).createBabyResult(babyRequest);
        Assertions.assertFalse(result);
    }

    /**
     * Test cases for constructor.
     */
    @Test
    public void testMockStaticMethods() {
        BabyResultDAOImpl babyResultDAOImpl = new BabyResultDAOImpl();
        Assertions.assertNotNull(babyResultDAOImpl);
    }
}