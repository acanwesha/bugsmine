package com.resultcopy.service.dao;

import com.resultcopy.BabyRequest;
import com.resultcopy.BabyResultResponse;

/**
 * @author AC089545 Interface BabyResultDAO containing all the methods to get the child result.
 */
public interface BabyResultDAO {

    /**
     * The method is used to get the Patient details by child Id.
     * 
     * @param childId
     *            Unique Identifier for a child.
     * 
     * @return The BabyResult for a child is returned.
     */
    BabyResultResponse getBabyPatientByChildId(Integer childId);

    /**
     * The method is used to copy the result to baby.
     * 
     * @param babyRequest
     *            {@link BabyRequest} Request body that is to be copied to baby.
     * 
     * @return The result that is to be copied is returned.
     */
    boolean createBabyResult(BabyRequest babyRequest);
}
