package com.resultcopy.service.dao;

import com.resultcopy.PatientDetailsResponse;
import java.util.List;

/**
 * @author AC089545
 * Interface ChildDAO containing the method to get the child details.
 */
public interface ChildDAO {

    /**
     * The method is declared to get the child details.
     * @param patientId {@link PatientDAO} Unique Identifier for a patient.
     * @return The child details are returned for a particular patient.
     */
    List<PatientDetailsResponse> getPatientById(Integer patientId);
}
