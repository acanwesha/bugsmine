package com.resultcopy.service;

import com.mysql.cj.jdbc.Driver;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * @author AC089545 Connection to database.
 */
public class ConnectionFactory {

    /**
     * Get a connection to database
     * 
     * @return Connection object
     */
    public static Connection getConnection() throws IOException {
        InputStream inputStream = new FileInputStream("Application.properties");
        Properties properties = new Properties();
        properties.load(inputStream);
        String URL = properties.getProperty("URL");
        String USER = properties.getProperty("USER");
        String PASS = properties.getProperty("PASS");
        try {
            DriverManager.registerDriver(new Driver());
            return DriverManager.getConnection(URL, USER, PASS);
        } catch (SQLException exception) {
            throw new RuntimeException("Error connecting to the database", exception);
        }
    }
}
