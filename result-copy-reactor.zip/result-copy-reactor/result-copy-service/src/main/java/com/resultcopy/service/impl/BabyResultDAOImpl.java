package com.resultcopy.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import com.resultcopy.BabyRequest;
import com.resultcopy.BabyResultResponse;
import com.resultcopy.CategoryRequest;
import com.resultcopy.ResultRequest;
import com.resultcopy.service.ConnectionFactory;
import com.resultcopy.service.dao.BabyResultDAO;

/**
 * @author AC089545
 * Returns the baby result details that are copied for a child.
 */
public class BabyResultDAOImpl implements BabyResultDAO {
    private Connection connection = null;

    /**
     * Constructor to set the connect for database.
     * @param connection {@link Connection} The databse connection object is set.
     */
    public BabyResultDAOImpl(Connection connection) {
        this.connection = connection;
    }

    /**
     * The database connection object is set.
     */
    public BabyResultDAOImpl() {
        this.connection = ConnectionFactory.getConnection();
    }

    /**
     * The method returns the result for a particular child.
     * @param childId Unique Identifier for a child.
     * @return The baby result response is returned.
     */
    @Override
    public BabyResultResponse getBabyPatientByChildId(Integer childId) {
        String sql = " SELECT * FROM Baby_Result WHERE CHILD_ID =  "+childId;
        BabyResultResponse babyResultResponse = null;
        try{
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                babyResultResponse = new BabyResultResponse();
                babyResultResponse.setDateTime(resultSet.getDate("DATE_TIME"));
            }
        }catch (SQLException exception){
            new RuntimeException("SQL Exception occured");
        }
        return babyResultResponse;
    }

    /**
     * The method is used to copy the result to the baby.
     * @param babyRequest {@link BabyRequest} Request body that is to be copied to baby.
     * @return A boolean value is returned based on the successful copy of result.
     */
    @Override
    public  boolean createBabyResult(BabyRequest babyRequest) {
        List<CategoryRequest> categoryList = babyRequest.getCategory();
        for(CategoryRequest categoryRequest:categoryList){
            List<ResultRequest> result = categoryRequest.getResult();
            for(ResultRequest resultRequest:result){
                String sql =    "insert into baby_result(child_id,value,category_name,result_name,date_time) " +
                        "Values ( "+babyRequest.getChildId()+" ,  '"+resultRequest.getValue() + "' , '" +
                        categoryRequest.getDisplayName() + "' , '" + resultRequest.getDisplayName() + "' , curtime() )";
                PreparedStatement preparedStatement = null;
                try {
                    preparedStatement = connection.prepareStatement(sql);
                    preparedStatement.executeUpdate();
                }catch (SQLException exception){
                    new RuntimeException("SQL Exception occured");
                    return false;
                }
            }
        }
        return true;
    }
}
