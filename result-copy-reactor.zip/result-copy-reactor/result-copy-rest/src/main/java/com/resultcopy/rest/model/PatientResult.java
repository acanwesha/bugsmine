package com.resultcopy.rest.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import javax.validation.constraints.*;
import javax.validation.Valid;

/**
 * Displays the patient details, child details, categories and result related to patient.
 */
@Schema(description = "Displays the patient details, child details, categories and result related to patient.")
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaJerseyServerCodegen", date = "2021-06-12T20:32:54.672Z[GMT]")
public class PatientResult {
    @JsonProperty("patient")
    private List<Patient> patient = new ArrayList<Patient>();
    @JsonProperty("patient")
    private Patient patientt;

    /**
     * Getter method for patient.
     * 
     * @return the patient information is returned.
     */
    public Patient getPatientt() {
        return patientt;
    }

    /**
     * Setter method for patient.
     * 
     * @param patientt
     *            {@link Patient} Details of a patient.
     */
    public void setPatientt(Patient patientt) {
        this.patientt = patientt;
    }

    @JsonProperty("child")
    private List<Child> child = new ArrayList<Child>();

    @JsonProperty("category")
    private List<Category> category = new ArrayList<Category>();

    /**
     * Constructor for list of Patients.
     * 
     * @param patient
     *            Information of a patient.
     * 
     * @return The list of patients are returned.
     */
    public PatientResult patient(List<Patient> patient) {
        this.patient = patient;
        return this;
    }

    /**
     * Information about the patient.
     * 
     * @return patient The information of a patient is returned.
     */
    @JsonProperty("patient")
    @Schema(required = true, description = "Information about the patient.")
    @NotNull
    @Valid
    public List<Patient> getPatient() {
        return patient;
    }

    /**
     * This method sets the patient information.
     * 
     * @param patient
     *            sets the patient information that is to be returned in patientResult class.
     */
    public void setPatient(List<Patient> patient) {
        this.patient = patient;
    }

    /**
     * Constructor for a child.
     * 
     * @param child
     *            {@link Child}
     * 
     * @return {@link PatientResult} Returns the child details.
     */
    public PatientResult child(List<Child> child) {
        this.child = child;
        return this;
    }

    /**
     * Information about the child.
     * 
     * @return child Returns the child details.
     */
    @JsonProperty("child")
    @Schema(required = true, description = "Information about the child.")
    @NotNull
    @Valid
    public List<Child> getChild() {
        return child;
    }

    /**
     * The method sets the child details.
     * 
     * @param child
     *            Sets the child information.
     */
    public void setChild(List<Child> child) {
        this.child = child;
    }

    /**
     * Constructor for category.
     * 
     * @param category
     *            Constructor for list of category.
     * 
     * @return category information.
     */
    public PatientResult category(List<Category> category) {
        this.category = category;
        return this;
    }

    /**
     * List of categories available as a part of patient reports.
     * 
     * @return category Returns the category.
     */
    @JsonProperty("category")
    @Schema(required = true, description = "List of categories available as a part of patient reports.")
    @NotNull
    @Valid
    public List<Category> getCategory() {
        return category;
    }

    /**
     * Sets the category information that is to be returned by patientResult class.
     * 
     * @param category
     *            sets the category information.
     */
    public void setCategory(List<Category> category) {
        this.category = category;
    }

    /**
     * Method to check object equality.
     * 
     * @param object
     *            object.hash of patient result.
     * 
     * @return return Objects.hash(patientResult);
     */
    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null || getClass() != object.getClass()) {
            return false;
        }
        PatientResult patientResult = (PatientResult) object;
        return Objects.equals(this.patient, patientResult.patient)
                && Objects.equals(this.patientt, patientResult.patient)
                && Objects.equals(this.child, patientResult.child)
                && Objects.equals(this.category, patientResult.category);
    }

    /**
     * hash code method.
     * 
     * @return object.hash of patient result.
     */
    @Override
    public int hashCode() {
        return Objects.hash(patient, patientt, child, category);
    }

    /**
     * toString method.
     * 
     * @return Converts the given patientResult object to string.
     */
    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("class PatientResult {\n");
        stringBuilder.append("    patient: ").append(toIndentedString(patientt)).append("\n");
        stringBuilder.append("    patient: ").append(toIndentedString(patient)).append("\n");
        stringBuilder.append("    child: ").append(toIndentedString(child)).append("\n");
        stringBuilder.append("    category: ").append(toIndentedString(category)).append("\n");
        stringBuilder.append("}");
        return stringBuilder.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces (except the first line).
     */
    private String toIndentedString(Object object) {
        if (object == null) {
            return "null";
        }
        return object.toString().replace("\n", "\n    ");
    }
}
