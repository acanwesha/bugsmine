package com.resultcopy.rest.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * CategoryPostResult which is used to set the list of result that can be copied.
 */
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaJerseyServerCodegen", date = "2021-06-21T13:02:06.679Z[GMT]")public class CategoryPostResult   {
  @JsonProperty("displayName")
  private String displayName = null;

  @JsonProperty("value")
  private String value = null;

  /**
   * Constructor for displayName of result.
   * @param displayName {@link CategoryPostResult} This is the displayName of result.
   * @return The displayName set for the result is returned.
   */
  public CategoryPostResult displayName(String displayName) {
    this.displayName = displayName;
    return this;
  }

  /**
   * Result Name for a particular category.
   * @return displayName {@link CategoryPostResult} The displayName for the result is returned.
   */
  @JsonProperty("displayName")
  @Schema(example = "PREGNANCY_OUTCOME", description = "Result Name for a particular category.")
  public String getDisplayName() {
    return displayName;
  }

  /**
   * Setter method for displayName of result.
   * @param displayName This is the displayName of result.
   */
  public void setDisplayName(String displayName) {
    this.displayName = displayName;
  }

  /**
   * Constructor for the value set for a result.
   * @param value {@link CategoryPostResult} This is the value set for a particular result.
   * @return The value set for a particular result is returned.
   */
  public CategoryPostResult value(String value) {
    this.value = value;
    return this;
  }

  /**
   * The method returns the value set for the result.
   * @return value This is the value of a particular result is returned.
   */
  @JsonProperty("value")
  @Schema(example = "VAGINAL BIRTH", description = "")
  public String getValue() {
    return value;
  }

  /**
   * Setter method for value of result.
   * @param value This is the value of a particular result.
   */
  public void setValue(String value) {
    this.value = value;
  }

  /**
   * Checks for object equalization.
   * @param object generated the object of babyResult.
   * @return boolean value on bject equality.
   */
  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null || getClass() != object.getClass()) {
      return false;
    }
    CategoryPostResult categoryPostResult = (CategoryPostResult) object;
    return Objects.equals(this.displayName, categoryPostResult.displayName) &&
        Objects.equals(this.value, categoryPostResult.value);
  }

  /**
   * Hash code method.
   * @return overriding hashcode.
   */
  @Override
  public int hashCode() {
    return Objects.hash(displayName, value);
  }

  /**
   * To string method.
   * @return to string method returns the string format of baby Result.
   */
  @Override
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("class CategoryPostResult {\n");
    
    stringBuilder.append("    displayName: ").append(toIndentedString(displayName)).append("\n");
    stringBuilder.append("    value: ").append(toIndentedString(value)).append("\n");
    stringBuilder.append("}");
    return stringBuilder.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object object) {
    if (object == null) {
      return "null";
    }
    return object.toString().replace("\n", "\n    ");
  }
}
