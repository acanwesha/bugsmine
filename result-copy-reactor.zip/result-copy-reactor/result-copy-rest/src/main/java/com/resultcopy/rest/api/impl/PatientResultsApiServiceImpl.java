package com.resultcopy.rest.api.impl;

import com.resultcopy.PatientResultResponse;
import com.resultcopy.PatientDetailsResponse;
import com.resultcopy.CategoryResponse;
import com.resultcopy.ResultResponse;
import com.resultcopy.BabyResultResponse;
import com.resultcopy.rest.api.PatientResultsApiService;
import com.resultcopy.rest.api.NotFoundException;
import com.resultcopy.rest.model.Child;
import com.resultcopy.rest.model.Patient;
import com.resultcopy.rest.model.PatientDetails;
import com.resultcopy.rest.model.Category;
import com.resultcopy.rest.model.Result;
import com.resultcopy.rest.model.PatientResult;
import com.resultcopy.service.dao.ResultDAO;
import com.resultcopy.service.impl.BabyResultDAOImpl;
import com.resultcopy.service.impl.ChildDAOImpl;
import com.resultcopy.service.impl.ResultDAOImpl;
import com.resultcopy.service.serviceimpl.PatientServiceImpl;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author AC089545 It is an API service class to return the patient details based on the patient identifier.
 */
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaJerseyServerCodegen", date = "2021-06-10T12:22:56.778Z[GMT]")
public class PatientResultsApiServiceImpl extends PatientResultsApiService {

    /**
     * This method returns the patientDetails based on patient identifier.
     * 
     * @param patientId
     *            Unique Identifer for patient.
     * @param securityContext
     *            {@link SecurityContext} this is the security context parameter which is swagger generated.
     * 
     * @return {@link Response} This is the response returned on the server.
     * 
     * @throws NotFoundException
     *             If the response is not found then it returns a NotFoundException.
     */
    @Override
    public Response patientResultsPatientIdGet(String patientId, SecurityContext securityContext)
            throws NotFoundException, IOException {
        Pattern pattern = Pattern.compile("[^(?=.*[1-9])\\d{1,3}(?:\\.\\d\\d?)?$]", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(patientId);
        boolean isValidPatientId = matcher.find();
        if (isValidPatientId) {
            return Response.status(Response.Status.BAD_REQUEST).type(MediaType.APPLICATION_JSON)
                    .entity("Bad request patientId must be a positive value.").build();
        }
        PatientServiceImpl patientService = new PatientServiceImpl();
        PatientResultResponse patientResponse = patientService.getPatientDetails(patientId);
        if (null == patientResponse.getPatient().getPatientDetails()) {
            return Response.status(Response.Status.NOT_FOUND).type(MediaType.APPLICATION_JSON)
                    .entity("A Patient with the specified Id was not found").build();
        }
        PatientResult patientResult = new PatientResult();
        Patient patient = new Patient();
        List<Patient> patients = new ArrayList<>();
        PatientDetails patientDetails = new PatientDetails();
        patientDetails.setId(patientResponse.getPatient().getPatientDetails().getId());
        patientDetails.firstName(patientResponse.getPatient().getPatientDetails().getFirstName());
        patientDetails.lastName(patientResponse.getPatient().getPatientDetails().getLastName());
        patientDetails.setMrn(patientResponse.getPatient().getPatientDetails().getMrn());
        patientDetails.setFin(patientResponse.getPatient().getPatientDetails().getFin());
        patient.setPatientDetails(patientDetails);
        patients.add(patient);
        patientResult.setPatient(patients);
        ChildDAOImpl childDAO = new ChildDAOImpl();
        List<PatientDetailsResponse> patientDetailsList = childDAO.getPatientById(Integer.parseInt(patientId));
        List<PatientDetails> patientDetailList = new ArrayList<>();
        for (PatientDetailsResponse patientList : patientDetailsList) {
            PatientDetails patientDetail = new PatientDetails();
            patientDetail.setId(patientList.getId());
            patientDetail.setFirstName(patientList.getFirstName());
            patientDetail.setLastName(patientList.getLastName());
            patientDetail.setMrn(patientList.getMrn());
            patientDetail.setFin(patientList.getFin());
            patientDetailList.add(patientDetail);
        }
        Child child = new Child();
        List<Child> childList = new ArrayList<>();
        childList.add(child);
        child.setChildDetails(patientDetailList);
        patientResult.setChild(childList);
        List<Category> categoryList = null;
        ResultDAO resultDAO = new ResultDAOImpl();
        Result result = null;
        List<Result> resultModelList = null;
        ResultResponse results = new ResultResponse();
        for (PatientDetails patientDetail : patientDetailList) {
            BabyResultDAOImpl babyResultDAO = new BabyResultDAOImpl();
            BabyResultResponse babyResultResponse = babyResultDAO.getBabyPatientByChildId(patientDetail.getId());
            if (null != babyResultResponse) {
                patientDetail.setResultCopiedDateTime(babyResultResponse.getDateTime());
            } else {
                List<CategoryResponse> categoryResponseList = patientResponse.getCategory();
                categoryList = new ArrayList<>();
                for (CategoryResponse categoryResponse : categoryResponseList) {
                    Category category = new Category();
                    category.setId(categoryResponse.getId());
                    category.setDisplayName(categoryResponse.getDisplayName());
                    List<ResultResponse> resultList = categoryResponse.getResult();
                    resultModelList = new ArrayList<>();
                    for (ResultResponse resultResponse : resultList) {
                        result = new Result();
                        result.setId(resultResponse.getId());
                        result.setDisplayName(resultResponse.getDisplayName());
                        result.setValue(resultResponse.getValue());
                        resultModelList.add(result);
                    }
                    category.setResult(resultModelList);
                    categoryList.add(category);
                }
                patientResult.setCategory(categoryList);
            }
        }
        patientResult.setPatientt(patient);
        patientResult.setChild(childList);
        return Response.ok().entity(patientResult).build();
    }
}
