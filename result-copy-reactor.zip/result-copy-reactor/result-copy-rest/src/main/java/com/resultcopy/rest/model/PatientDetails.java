package com.resultcopy.rest.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.Date;
import java.util.Objects;

/**
 * Demographic information.
 */
@Schema(description = "Demographic information.")
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaJerseyServerCodegen", date = "2021-06-10T12:22:56.778Z[GMT]")public class PatientDetails   {
  @JsonProperty("id")
  private Integer id = null;

  @JsonProperty("firstName")
  private String firstName = null;

  @JsonProperty("lastName")
  private String lastName = null;

  @JsonProperty("mrn")
  private String mrn = null;

  @JsonProperty("fin")
  private String fin = null;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
  private Date resultCopiedDateTime;

  /**
   * Getter method for date and time which is returned when result is copied.
   * @return resultCopiedDateTime is returned.
   */
  public Date getResultCopiedDateTime() {
    return resultCopiedDateTime;
  }

  /**
   * Setter method for date and time which is returned when result is copied.
   * @param resultCopiedDateTime {@link PatientDetails} Date and time which is returned when result is copied.
   */
  public void setResultCopiedDateTime(Date resultCopiedDateTime) {
    this.resultCopiedDateTime = resultCopiedDateTime;
  }

  /**
   * Constructor for unique identifier of a Patient.
   * @param id {@link PatientDetails} Unique identifier of a Patient
   * @return Unique identifier of a Patient is returned.
   */
  public PatientDetails id(Integer id) {
    this.id = id;
    return this;
  }

  /**
   * Unique Identifier of a patient.
   * @return id The unique identifier for patient is returned.
   */
  @JsonProperty("id")
  @Schema(example = "35", description = "Identifier of a patient.")
  public Integer getId() {
    return id;
  }

  /**
   * The method sets the unique identifier for a patient.
   * @param id sets the unique identifier for a patient.
   */
  public void setId(Integer id) {
    this.id = id;
  }

  /**
   * This is a constructor to set the firstName.
   * @param firstName {@link PatientDetails} constructor for firstName of patient.
   * @return firstName First Name for a patient is returned.
   */
  public PatientDetails firstName(String firstName) {
    this.firstName = firstName;
    return this;
  }

  /**
   * This is the first name of a patient that is returned.
   * @return firstName Returns the firstName of patient.
   */
  @JsonProperty("firstName")
  @Schema(example = "JOEE", description = "This is the first name of a patient.")
  public String getFirstName() {
    return firstName;
  }

  /**
   * Sets the firstName for a patient.
   * @param firstName Sets the firstName for a patient.
   */
  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  /**
   * This is the constructor for last name of a patient.
   * @param lastName {@link PatientDetails} constructor for lastName of patient.
   * @return the last name set for a patient.
   */
  public PatientDetails lastName(String lastName) {
    this.lastName = lastName;
    return this;
  }


  /**
   * This is the last name of a patient.
   * @return lastName Last Name for patient is returned.
   */
  @JsonProperty("lastName")
  @Schema(example = "ROBERTS", description = "This is the last name of a patient.")
  public String getLastName() {
    return lastName;
  }

  /**
   * Sets the lastName of a Patient.
   * @param lastName Sets the lastName of a patient.
   */
  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  /**
   * This is the Medical Record Number set for the patient.
   * @param mrn {@link PatientDetails} constructor for mrn associated with patient.
   * @return {@link PatientDetails} Details of patient is returned.
   */
  public PatientDetails mrn(String mrn) {
    this.mrn = mrn;
    return this;
  }

  /**
   * This is the Medical Record Number allocated for the patient.
   * @return mrn Returns the mrn for a patient.
   */
  @JsonProperty("mrn")
  @Schema(example = "MX134566", description = "This is the mrn allocated for the patient.")
  public String getMrn() {
    return mrn;
  }

  /**
   * This is the Medical Record Number allocated for the patient.
   * @return mrn Returns the mrn for a patient.
   */
  public void setMrn(String mrn) {
    this.mrn = mrn;
  }

  /**
   * constructor for fin (Financial Identification Number) of a patient.
   * @param fin {@link PatientDetails}
   * @return {@link PatientDetails} fin is returned.
   */
  public PatientDetails fin(String fin) {
    this.fin = fin;
    return this;
  }

  /**
   * This is the Financial Identification Number allocated for the patient.
   * @return fin FIN of a patient is returned.
   */
  @JsonProperty("fin")
  @Schema(example = "MH134566", description = "This is the fin allocated for the patient.")
  public String getFin() {
    return fin;
  }

  /**
   * This method sets the Financial Identification Number of a patient.
   * @param fin sets the fin of a patient.
   */
  public void setFin(String fin) {
    this.fin = fin;
  }

  /**
   * Method to check equality of objects.
   *  @param object object generated.
   *  @return return Objects.hash(patientDetails);
   */
  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null || getClass() != object.getClass()) {
      return false;
    }
    PatientDetails patientDetails = (PatientDetails) object;
    return Objects.equals(this.id, patientDetails.id) &&
        Objects.equals(this.firstName, patientDetails.firstName) &&
        Objects.equals(this.lastName, patientDetails.lastName) &&
        Objects.equals(this.mrn, patientDetails.mrn) &&
        Objects.equals(this.fin, patientDetails.fin);
  }

  /**
   * hash code method.
   * @return object.hash of patient details.
   */
  @Override
  public int hashCode() {
    return Objects.hash(id, firstName, lastName, mrn, fin);
  }

  /**
   * Convert the given patient object to string.
   */
  @Override
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("class PatientDetails {\n");
    stringBuilder.append("    id: ").append(toIndentedString(id)).append("\n");
    stringBuilder.append("    firstName: ").append(toIndentedString(firstName)).append("\n");
    stringBuilder.append("    lastName: ").append(toIndentedString(lastName)).append("\n");
    stringBuilder.append("    mrn: ").append(toIndentedString(mrn)).append("\n");
    stringBuilder.append("    fin: ").append(toIndentedString(fin)).append("\n");
    stringBuilder.append("}");
    return stringBuilder.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object object) {
    if (object == null) {
      return "null";
    }
    return object.toString().replace("\n", "\n    ");
  }
}
