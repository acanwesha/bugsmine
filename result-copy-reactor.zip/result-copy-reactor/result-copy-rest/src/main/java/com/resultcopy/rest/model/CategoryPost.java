package com.resultcopy.rest.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.List;
import javax.validation.Valid;

/**
 * List of categories available as a part of patient reports.
 */
@Schema(description = "List of categories available as a part of patient reports.")
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaJerseyServerCodegen", date = "2021-06-21T13:02:06.679Z[GMT]")
public class CategoryPost {
    @JsonProperty("displayName")
    private String displayName = null;

    @JsonProperty("result")
    private List<CategoryPostResult> result = null;

    /**
     * Constructor for displayName of category.
     * 
     * @param displayName
     *            {@link CategoryPost} This is the displayName for category.
     * 
     * @return The displayName set for category is returned.
     */
    public CategoryPost displayName(String displayName) {
        this.displayName = displayName;
        return this;
    }

    /**
     * Name of the category.
     * 
     * @return displayName. The method returns the displayName of category.
     */
    @JsonProperty("displayName")
    @Schema(example = "DELIVERY_INFORMATION", description = "Name of the category.")
    public String getDisplayName() {
        return displayName;
    }

    /**
     * This is the setter method to set the displayName of category.
     * 
     * @param displayName
     *            This is the displayName for category.
     */
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    /**
     * Constructor for resultList.
     * 
     * @param result
     *            This is the resultList for a particular category.
     * 
     * @return The result set for category is returned.
     */
    public CategoryPost result(List<CategoryPostResult> result) {
        this.result = result;
        return this;
    }

    /**
     * List of result details documented for the mother patient.
     * 
     * @return result {@link CategoryPostResult} The result details of category is returned.
     */
    @JsonProperty("result")
    @Schema(description = "List of result details documented for the mother patient.")
    @Valid
    public List<CategoryPostResult> getResult() {
        return result;
    }

    /**
     * Setter method for list of results.
     * 
     * @param result
     *            {@link CategoryPostResult}The result for Category is set.
     */
    public void setResult(List<CategoryPostResult> result) {
        this.result = result;
    }

    /**
     * Checks for object equalization.
     * 
     * @param object
     *            generated the object of babyResult.
     * 
     * @return boolean value on bject equality.
     */
    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null || getClass() != object.getClass()) {
            return false;
        }
        CategoryPost categoryPost = (CategoryPost) object;
        return Objects.equals(this.displayName, categoryPost.displayName)
                && Objects.equals(this.result, categoryPost.result);
    }

    /**
     * Hash code method.
     * 
     * @return overriding hashcode.
     */
    @Override
    public int hashCode() {
        return Objects.hash(displayName, result);
    }

    /**
     * To string method.
     * 
     * @return to string method returns the string format of baby Result.
     */
    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("class CategoryPost {\n");
        stringBuilder.append("    displayName: ").append(toIndentedString(displayName)).append("\n");
        stringBuilder.append("    result: ").append(toIndentedString(result)).append("\n");
        stringBuilder.append("}");
        return stringBuilder.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces (except the first line).
     */
    private String toIndentedString(Object object) {
        if (object == null) {
            return "null";
        }
        return object.toString().replace("\n", "\n    ");
    }
}
