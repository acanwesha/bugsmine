package com.resultcopy.rest.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.Valid;
import java.util.List;
import java.util.Objects;

/**
 * Information about the child.
 */
@Schema(description = "Information about the child.")
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaJerseyServerCodegen", date = "2021-06-10T12:22:56.778Z[GMT]")public class Child   {
  @JsonProperty("childDetails")
  private List<PatientDetails> childDetails = null;

  /**
   * Constructor for child details.
   * @param childDetails {@link Child} Details of a particular child.
   * @return Returns the details of a child.
   */
  public Child childDetails(List<PatientDetails> childDetails) {
    this.childDetails = childDetails;
    return this;
  }


  /**
   * Information of the child.
   * @return childDetails. The child details are returned.
   */
  @JsonProperty("childDetails")
  @Schema(description = "Information of the child.")
  @Valid
  public List<PatientDetails> getChildDetails() {
    return childDetails;
  }

  /**
   * Setter method for child details.
   * @param childDetails The details of the child.
   */
  public void setChildDetails(List<PatientDetails> childDetails) {
    this.childDetails = childDetails;
  }

  /**
   * Checks for object equalization.
   * @param object generated the object of babyResult.
   * @return boolean value on bject equality.
   */
  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null || getClass() != object.getClass()) {
      return false;
    }
    Child child = (Child) object;
    return Objects.equals(this.childDetails, child.childDetails);
  }

  /**
   * Hash code method.
   * @return overriding hashcode.
   */
  @Override
  public int hashCode() {
    return Objects.hash(childDetails);
  }

  /**
   * To string method.
   * @return to string method returns the string format of baby Result.
   */
  @Override
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("class Child {\n");
    
    stringBuilder.append("    childDetails: ").append(toIndentedString(childDetails)).append("\n");
    stringBuilder.append("}");
    return stringBuilder.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object object) {
    if (object == null) {
      return "null";
    }
    return object.toString().replace("\n", "\n    ");
  }
}
